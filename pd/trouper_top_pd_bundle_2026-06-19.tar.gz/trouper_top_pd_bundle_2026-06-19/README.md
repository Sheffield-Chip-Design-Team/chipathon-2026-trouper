# Trouper Top — PD Bundle (2026-06-19, rev 2)

SSCS PICO Chipathon 2026 · GF180MCU (gf180mcuD) · 3.3 V core/IO · 32 MHz

## Context

This is a DSP-only hardened macro for an NT=1 NR=4 MRC MIMO LoRa gateway. It
contains no embedded CPU. Host control enters via the SPI slave and the `GRP_*`
register bus.

Signal chain: 4× SX1257 1-bit IQ → CIC TDM8 decimator → DC removal →
Schmidl-Cox sync → training accumulator → MRC combiner → ΣΔ re-modulator → SX1302.

## Die size roadmap

| Config | Die | Status |
|---|---|---|
| `config_exp_tdm8_1375x1100.json` | 1375×1100 µm | **Primary baseline — clean timing, use this first** |
| `config_exp_tdm8_lshape_1650x1100.json` | 1650×1100 µm rect + 550×550 blocked corner (L-shape) | Parallel exploration — routable but WNS=-3.23 ns |
| *(future)* | 1100×1100 µm | Final target — pending further RTL area cuts |

The 1375×1100 rectangle is the recommended starting point. The L-shape config
explores whether an L-shaped floorplan (equivalent usable area to 1.1×1.1 +
0.55×0.55 mm²) can route cleanly before timing closure work is done.

## Last known P&R results (2026-06-14)

### 1375×1100 rectangle
- Utilisation: 62.79%
- Setup WNS: 0 ns (all corners)
- Hold WNS: 0 ns
- Antenna violations: 1 net / 1 pin (minor)
- DRC / LVS: not run yet

### L-shape 1650×1100
- Utilisation: 51.96%
- Setup WNS: -3.23 ns (SS corner)
- Hold WNS: 0 ns
- Antenna violations: 1 net / 1 pin

## Timing strategy

SDC: `pd/pnr_32m_mcp_v6.sdc`

- Clock: `IQ_CLK` 31.25 ns (32 MHz)
- MCP=3 setup / MCP=2 hold (93.75 ns effective budget)
- Clock uncertainty: 0.5 ns
- Rationale: `gf180mcu_fd_sc_mcu7t5v0` is characterised at 3 V SS but designed
  for 5 V; deep combinational paths exceed 62.5 ns at SS. MCP=3 is the current
  workaround. Per-path analysis to tighten this has not been done yet.

## Standard cell library

`gf180mcu_fd_sc_mcu7t5v0` (FD cells, 3.3 V). Lib paths in the JSON configs
point to `/foss/pdks/gf180mcuD/...` as found in `hpretl/iic-osic-tools:chipathon26`.

## PDN

No hard macros present (SRAM removed from this top-level). Standard stdcell
grid only — `pd/pdn_cfg.tcl`.

## Running LibreLane

Extract this bundle so that `rtl/` and `pd/` sit at the same level, then run
inside the `hpretl/iic-osic-tools:chipathon26` Docker image. **Do not use
`:latest` or `:2026.04` — the exact tag matters for reproducibility.**

```bash
# Pull the image (once)
docker pull hpretl/iic-osic-tools:chipathon26

# Primary 1375×1100 run (recommended starting point)
docker run --rm \
  --user $(id -u):$(id -g) \
  -v $(pwd):/foss/designs/trouper \
  hpretl/iic-osic-tools:chipathon26 --skip \
  bash -c "cd /foss/designs/trouper && \
    librelane --pdk gf180mcuD \
              --scl gf180mcu_fd_sc_mcu7t5v0 \
              pd/config_exp_tdm8_1375x1100.json"

# L-shape exploration (WNS=-3.23 ns at SS — needs timing work)
docker run --rm \
  --user $(id -u):$(id -g) \
  -v $(pwd):/foss/designs/trouper \
  hpretl/iic-osic-tools:chipathon26 --skip \
  bash -c "cd /foss/designs/trouper && \
    librelane --pdk gf180mcuD \
              --scl gf180mcu_fd_sc_mcu7t5v0 \
              pd/config_exp_tdm8_lshape_1650x1100.json"
```

Run these from the directory containing the extracted bundle (i.e. where `rtl/`
and `pd/` are visible). The `VERILOG_FILES` paths in the JSON use `dir::../rtl/`
relative to the config file, so the directory layout must be preserved.

Run outputs land in `ol_trouper_top/runs/RUN_*/` alongside the config. Key
result files:

```bash
# Post-PNR SS timing WNS
cat ol_trouper_top/runs/RUN_*/56-openroad-stapostpnr/max_ss_125C_3v00/wns.max.rpt

# Magic DRC error count
python3 -c "
import json, glob
f = sorted(glob.glob('ol_trouper_top/runs/RUN_*/66-checker-magicdrc/state_out.json'))[-1]
print(json.load(open(f)).get('metrics',{}).get('magic__drc_error__count','not found'))"
```

## RTL files (12 sources)

| File | Block |
|---|---|
| `trouper_top.v` | Top-level integration |
| `sd_decimator_cic_tdm8.v` | CIC R=128 TDM8 decimator (4-ch time-multiplexed) |
| `dc_removal.v` | IIR DC removal, α=2^{-4} |
| `sc_detector.v` | Schmidl-Cox preamble detector |
| `training_acc.v` | All-pairs cross-correlator (Z matrix) |
| `mrc_combiner.v` | MRC combiner ŷ=w^H·x, Q0.7 weights, combined-shift output |
| `packet_ctrl_fsm.v` | Packet control FSM |
| `psram_buf_ctrl.v` | PSRAM buffer controller (APS6404L QPI) |
| `weight_gen.v` | Weight generation (EGC/MRC/SC HW modes + ALMMSE via CPU) |
| `reg_bank.v` | 7-bit register bank (0x00–0x7F) |
| `spi_slave.v` | SPI slave (Mode 0, up to 10 MHz) |
| `sd_remod.v` | 3rd-order ΣΔ re-modulator, int8→1-bit |

## RTL changes since rev 1 (2026-06-19)

- **`mrc_combiner.v`** — Output shift changed from two-step `(acc>>>8)<<pgs` to
  single combined `acc>>>(8−pgs)`. Eliminates amplified truncation error (old
  worst-case loss ~1.94 dB at pgs=3; new < 0.05 dB across all tiers). Verified:
  1014/1014 random cases PASS, 5/5 precision cases PASS, 6/6 unit tests PASS.
- **`weight_gen.v`** — Added (was missing from rev 1).

## Known open issues

1. **MCP=3 is blanket**: no per-path analysis done; some paths may not need it.
2. **DRC/LVS**: not run on either floorplan yet.
3. **L-shape WNS**: -3.23 ns at SS corner — needs timing closure before use.
