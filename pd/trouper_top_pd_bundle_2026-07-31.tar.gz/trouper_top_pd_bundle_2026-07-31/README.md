# trouper_top PD bundle — 2026-07-31

Replaces `trouper_top_pd_bundle_2026-06-19.tar.gz`, which only contained configs + RTL
copies (no GDS, no timing/DRC reports — "DRC/LVS: not run yet"), and hardened the
wrong decimator variant (`sd_decimator_cic_tdm8.v` + `weight_gen.v`, a stale test-only
branch). This bundle is the actual current signoff result, matching what tapes out:
`sd_decimator_poly.v` in `src/`.

## Source run

`rtl-test/ol_trouper_top/config_current_signoff.json`, SDC `pnr_32m_scoped_v25_b6.sdc`
(both copied into `configs/`), LibreLane run
`rtl-test/ol_trouper_top/runs/RUN_2026-07-25_14-41-00`.

- Die: 1200×1100 µm (fixed), core area 1,264,650 µm²
- Placement density target 88%, actual ~86.3% (`design__instance__area__stdcell` /
  `design__core__area` pre-fill, see `reports/final_metrics.json`)
- Cell count: 70,858 instances, 1,264,650 µm² placed (incl. fill)
- Magic DRC: clean, 0 errors (`reports/drc.magic.rpt`, empty = clean)
- LVS: not run as part of this particular flow invocation

## Timing

`reports/sta_3v3_signoff/` — the actual signoff corners (`gf180mcu_fd_sc_mcu7t5v0` at
native 3.0–3.3V core):

| Corner | Setup WNS | Setup TNS |
|---|---|---|
| `nom_tt_025C_3v30` | 0.0 ns | 0.0 |
| `max_ss_125C_3v00` | **−14.91 ns** | −5747.3 |
| `max_ff_n40C_3v60` | 0.0 ns | 0.0 |

`reports/sta_4v50_rerun/` — a same-netlist re-timing experiment (no re-placement/
re-optimization; identical routed netlist/DEF/SPEF as above, just the SS corner's
liberty file swapped from `ss_125C_3v00` to `ss_125C_4v50` and OpenSTA re-run standalone,
SGE job 3732):

| Corner | Setup WNS | Setup TNS |
|---|---|---|
| `nom_tt_025C_3v30` | 0.0 ns | 0.0 |
| `max_ss_125C_4v50` | **0.0 ns** | 0.0 |
| `max_ff_n40C_3v60` | 0.0 ns | 0.0 |

Confirms the known 5V-characterized-library-at-3V timing gap is a voltage problem: the
exact same physical implementation meets timing cleanly once the SS corner is evaluated
at 4.5V instead of 3.0V. This is not a full P&R re-run at 4.5V (which would re-optimize
placement/CTS/routing against different libs and wouldn't isolate the voltage effect) —
it's a frozen-netlist re-timing to isolate that one variable.

## Contents

- `gds/trouper_top.gds` — final GDSII (Magic streamout)
- `reports/drc.magic.rpt` — Magic DRC report (empty = 0 errors)
- `reports/synth_stat.rpt` — Yosys synthesis cell/area breakdown
- `reports/final_metrics.json` — full LibreLane metrics snapshot for the signoff run
- `reports/sta_3v3_signoff/<corner>/{wns,tns}.{max,min}.rpt` — signoff timing per corner
- `reports/sta_4v50_rerun/<corner>/{wns,tns}.{max,min}.rpt` — 4.5V re-timing experiment
- `configs/config_current_signoff.json`, `configs/pnr_32m_scoped_v25_b6.sdc` — the
  LibreLane config and SDC that produced this run
